<template>
    <h2 class="centralizado">Cadastro</h2>
</template>
<script>

</script>
<style>

    .centralizado {

        text-align: center;
    }
</style>